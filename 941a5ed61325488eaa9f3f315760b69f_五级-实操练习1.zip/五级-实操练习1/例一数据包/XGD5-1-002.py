# 1.读取CSV文件中的数据到Pandas DataFrame中，将DataFrame的前5  行数据打印到控制台并截图保存为XGD5_001.png。
import pandas as pd
# 读取CSV文件
df = pd.read_csv('./beijing_202404.csv', encoding='gbk')

# 2.检查数据中是否存在缺失值和重复值，删除包含缺失值的行和重复行，保存清理后的数据到cleaned.csv文件中。
# 检查缺失值
missing_values = df.isnull().sum()
print("存在缺失值的列：")
print(missing_values[missing_values > 0])
# 删除包含缺失值的行
df_cleaned = df.dropna()
# 检查重复值
duplicates = df_cleaned.duplicated().sum()
print("原始数据中重复的行数：", duplicates)
# 删除重复行
df_no_duplicates = df_cleaned.drop_duplicates()
# 保存清理后的数据到cleaned.csv文件中
df_no_duplicates.to_csv('cleaned.csv', index=False, encoding='gbk')