# 1.读取CSV文件中的数据到Pandas DataFrame中，将DataFrame的前5  行数据打印到控制台并截图保存为XGD5_001.png。
import pandas as pd
# 读取CSV文件
df = pd.read_csv('./beijing_202404.csv', encoding='gbk')
# 打印前5行数据
print(df.head(5))
