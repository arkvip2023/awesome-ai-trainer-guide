# 1.读取CSV文件中的数据到Pandas DataFrame中，将DataFrame的前5  行数据打印到控制台并截图保存为XGD5_001.png。
import pandas as pd
# 读取CSV文件
df = pd.read_csv('./beijing_202404.csv', encoding='gbk')

# 删除包含缺失值的行
df_cleaned = df.dropna()

# 5.找出工资最高的员工信息，并截图保存为XGD5_003.png。
highest_salary_employee = df_cleaned.loc[df_cleaned['so2'].idxmax()]
print("二氧化硫最高的条目信息：")
# 填充代码的xxxxx部分，最终完成题目要求
print(xxxxx)
