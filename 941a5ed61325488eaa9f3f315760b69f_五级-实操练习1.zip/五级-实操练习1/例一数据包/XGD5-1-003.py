# 1.读取CSV文件中的数据到Pandas DataFrame中，将DataFrame的前5  行数据打印到控制台并截图保存为XGD5_001.png。
import pandas as pd
# 读取CSV文件
df = pd.read_csv('./beijing_202404.csv', encoding='gbk')

# 2.检查数据中是否存在缺失值和重复值，删除包含缺失值的行和重复行，保存清理后的数据到cleaned.csv文件中。
# 删除包含缺失值的行
df_cleaned = df.dropna()

# 3.筛选出臭氧大于40的员工，并按照二氧化硫从高到低排序。将排序后的结果保存到order_by_so2.csv文件中。
filtered_df = df_cleaned[df_cleaned['o3'] > 40]
sorted_df = filtered_df.sort_values(by='so2', ascending=False)
# 将排序后的结果保存到CSV文件order_by_so2.csv中
sorted_df.to_csv('order_by_so2.csv', index=False,  encoding='gbk')
print('成功保存order_by_so2.csv')
