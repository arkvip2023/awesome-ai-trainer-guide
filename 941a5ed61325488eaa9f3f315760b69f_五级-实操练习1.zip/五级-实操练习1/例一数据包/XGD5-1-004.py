# 1.读取CSV文件中的数据到Pandas DataFrame中，将DataFrame的前5  行数据打印到控制台并截图保存为XGD5_001.png。
import pandas as pd
# 读取CSV文件
df = pd.read_csv('./beijing_202404.csv', encoding='gbk')

# 2.检查数据中是否存在缺失值和重复值，删除包含缺失值的行和重复行，保存清理后的数据到cleaned.csv文件中。
# 删除包含缺失值的行
df_cleaned = df.dropna()

# 4.计算平均一氧化碳，并截图保存为XGD5_002.png。
average_co = df_cleaned['co'].mean()
print("平均co指标为：", average_co)