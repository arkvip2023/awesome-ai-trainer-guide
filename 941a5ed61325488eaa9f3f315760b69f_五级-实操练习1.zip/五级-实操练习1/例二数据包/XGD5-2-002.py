# 导入操作库
import pandas as pd
# 读取数据集
df = pd.read_csv('./beijing_scenery.csv',  encoding='gbk')
# 删除列明中含有空格
ClName = df.columns.values
df.columns = [x.strip() for x in ClName]
print(df.columns.values)
