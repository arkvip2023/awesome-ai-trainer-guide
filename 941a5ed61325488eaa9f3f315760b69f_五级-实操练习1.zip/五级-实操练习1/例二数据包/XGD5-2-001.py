# 导入操作库
import pandas as pd
# 读取数据集
df = pd.read_csv('./beijing_scenery.csv',  encoding='gbk')
# 获取数据集中的列名
print(df.columns.values)
